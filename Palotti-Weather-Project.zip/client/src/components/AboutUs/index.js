import Navbar from '../Navbar'
import Footer from '../Footer'

import './index.css'

const AboutUs = ()=>(
    <>
        <Navbar/>
            <div className='about-container'>
                <h1>AboutUs</h1>
            </div>
        <Footer/>
    </>
)

export default AboutUs